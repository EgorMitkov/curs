﻿using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;

namespace home
{
    public partial class CatalogPage : Page, INotifyPropertyChanged
    {
        private bool _addProductDialogIsVisible;
        private bool _updatePriceDialogIsVisible;
        private Product _selectedProduct;

        public CatalogPage()
        {
            InitializeComponent();
            DataContext = this;
        }

        public System.Collections.ObjectModel.ObservableCollection<Product> Products => DataManager.Products;
        public System.Collections.ObjectModel.ObservableCollection<Warehouse> Warehouses => DataManager.Warehouses;
        public string[] Categories => DataManager.Categories;

        public bool AddProductDialogIsVisible
        {
            get => _addProductDialogIsVisible;
            set
            {
                _addProductDialogIsVisible = value;
                OnPropertyChanged();
            }
        }

        public bool UpdatePriceDialogIsVisible
        {
            get => _updatePriceDialogIsVisible;
            set
            {
                _updatePriceDialogIsVisible = value;
                OnPropertyChanged();
            }
        }

        public Product SelectedProduct
        {
            get => _selectedProduct;
            set
            {
                _selectedProduct = value;
                OnPropertyChanged();
            }
        }

        // Обработчики для кнопок действий
        private void AddProduct_Click(object sender, RoutedEventArgs e)
        {
            AddProductDialogIsVisible = true;
        }

        private void UpdatePrices_Click(object sender, RoutedEventArgs e)
        {
            if (ProductsDataGrid.SelectedItem is Product selectedProduct)
            {
                SelectedProduct = selectedProduct;
                UpdatePriceDialogIsVisible = true;
            }
            else
            {
                MessageBox.Show("Выберите товар для изменения цены!", "Внимание",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void ConfirmAddProduct_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(NewProductNameTextBox.Text) ||
                string.IsNullOrWhiteSpace(NewProductCategoryComboBox.Text) ||
                string.IsNullOrWhiteSpace(NewProductPriceTextBox.Text) ||
                string.IsNullOrWhiteSpace(NewProductQuantityTextBox.Text) ||
                NewProductWarehouseComboBox.SelectedItem == null)
            {
                MessageBox.Show("Заполните все поля!", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            if (decimal.TryParse(NewProductPriceTextBox.Text, out decimal price) &&
                int.TryParse(NewProductQuantityTextBox.Text, out int quantity) &&
                NewProductWarehouseComboBox.SelectedItem is Warehouse selectedWarehouse)
            {
                var newProduct = new Product
                {
                    Category = NewProductCategoryComboBox.Text,
                    Name = NewProductNameTextBox.Text,
                    Price = price,
                    CostPrice = price * 0.7m, // Себестоимость 70% от цены
                    Quantity = quantity,
                    WarehouseId = selectedWarehouse.Id
                };

                DataManager.AddProduct(newProduct);

                // Очистка полей
                NewProductNameTextBox.Text = "";
                NewProductPriceTextBox.Text = "";
                NewProductQuantityTextBox.Text = "";
                NewProductCategoryComboBox.SelectedIndex = -1;
                NewProductWarehouseComboBox.SelectedIndex = -1;

                AddProductDialogIsVisible = false;
                MessageBox.Show("Товар добавлен!", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else
            {
                MessageBox.Show("Проверьте правильность введенных данных!", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ConfirmUpdatePrice_Click(object sender, RoutedEventArgs e)
        {
            if (SelectedProduct != null && decimal.TryParse(NewPriceTextBox.Text, out decimal newPrice))
            {
                DataManager.UpdateProductPrice(SelectedProduct.Id, newPrice);
                UpdatePriceDialogIsVisible = false;
                MessageBox.Show($"Цена товара '{SelectedProduct.Name}' обновлена!", "Успех",
                    MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else
            {
                MessageBox.Show("Введите корректную цену!", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void CancelAddProduct_Click(object sender, RoutedEventArgs e)
        {
            AddProductDialogIsVisible = false;
        }

        private void CancelUpdatePrice_Click(object sender, RoutedEventArgs e)
        {
            UpdatePriceDialogIsVisible = false;
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}