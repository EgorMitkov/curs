﻿using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;

namespace home
{
    public partial class PurchasesPage : Page, INotifyPropertyChanged
    {
        private bool _searchSuppliersDialogIsVisible;
        private bool _orderDialogIsVisible;
        private List<Supplier> _foundSuppliers = new List<Supplier>();
        private Supplier _selectedSupplierForOrder;
        private Warehouse _selectedWarehouseForOrder;
        private string _newProductName;
        private string _newProductCategory;
        private decimal _newProductCostPrice;
        private decimal _newProductPrice;

        public PurchasesPage()
        {
            InitializeComponent();
            DataContext = this;
        }

        public System.Collections.ObjectModel.ObservableCollection<Supplier> Suppliers => DataManager.Suppliers;
        public System.Collections.ObjectModel.ObservableCollection<Purchase> Purchases => DataManager.Purchases;
        public System.Collections.ObjectModel.ObservableCollection<Warehouse> Warehouses => DataManager.Warehouses;
        public string[] Categories => DataManager.Categories;

        public bool SearchSuppliersDialogIsVisible
        {
            get => _searchSuppliersDialogIsVisible;
            set
            {
                _searchSuppliersDialogIsVisible = value;
                OnPropertyChanged();
            }
        }

        public bool OrderDialogIsVisible
        {
            get => _orderDialogIsVisible;
            set
            {
                _orderDialogIsVisible = value;
                OnPropertyChanged();
            }
        }

        public List<Supplier> FoundSuppliers
        {
            get => _foundSuppliers;
            set
            {
                _foundSuppliers = value;
                OnPropertyChanged();
            }
        }

        public Supplier SelectedSupplierForOrder
        {
            get => _selectedSupplierForOrder;
            set
            {
                _selectedSupplierForOrder = value;
                OnPropertyChanged();
            }
        }

        public Warehouse SelectedWarehouseForOrder
        {
            get => _selectedWarehouseForOrder;
            set
            {
                _selectedWarehouseForOrder = value;
                OnPropertyChanged();
            }
        }

        public string NewProductName
        {
            get => _newProductName;
            set
            {
                _newProductName = value;
                OnPropertyChanged();
            }
        }

        public string NewProductCategory
        {
            get => _newProductCategory;
            set
            {
                _newProductCategory = value;
                OnPropertyChanged();
            }
        }

        public decimal NewProductCostPrice
        {
            get => _newProductCostPrice;
            set
            {
                _newProductCostPrice = value;
                OnPropertyChanged();
                OnPropertyChanged(nameof(OrderTotalAmount));
            }
        }

        public decimal NewProductPrice
        {
            get => _newProductPrice;
            set
            {
                _newProductPrice = value;
                OnPropertyChanged();
            }
        }

        public decimal OrderTotalAmount
        {
            get
            {
                if (int.TryParse(OrderQuantityTextBox?.Text, out int quantity))
                {
                    return NewProductCostPrice * quantity;
                }
                return 0;
            }
        }

        // Обработчики для кнопок действий
        private void SearchSuppliers_Click(object sender, RoutedEventArgs e)
        {
            // Имитация поиска поставщиков
            var foundSuppliers = new List<Supplier>()
            {
                new Supplier { Id = 100, Name = "ООО 'ТехноПоставка'", Contact = "+7 (495) 111-22-33", Rating = 4.7 },
                new Supplier { Id = 101, Name = "ИП Сидоров", Contact = "+7 (812) 444-55-66", Rating = 4.3 },
                new Supplier { Id = 102, Name = "АО 'Оптовые закупки'", Contact = "+7 (843) 777-88-99", Rating = 4.5 }
            };

            FoundSuppliers = foundSuppliers;
            SearchSuppliersDialogIsVisible = true;
        }

        private void AddSupplier_Click(object sender, RoutedEventArgs e)
        {
            if (FoundSuppliersDataGrid.SelectedItem is Supplier selectedSupplier)
            {
                // Проверяем, нет ли уже такого поставщика
                if (!DataManager.Suppliers.Any(s => s.Name == selectedSupplier.Name))
                {
                    DataManager.AddSupplier(selectedSupplier);
                    MessageBox.Show($"Поставщик '{selectedSupplier.Name}' добавлен!", "Успех",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                    SearchSuppliersDialogIsVisible = false;
                }
                else
                {
                    MessageBox.Show("Этот поставщик уже есть в списке!", "Внимание",
                        MessageBoxButton.OK, MessageBoxImage.Warning);
                }
            }
            else
            {
                MessageBox.Show("Выберите поставщика из списка!", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void OrderGoods_Click(object sender, RoutedEventArgs e)
        {
            // Сброс полей при открытии диалога
            NewProductName = "";
            NewProductCategory = null;
            NewProductCostPrice = 0;
            NewProductPrice = 0;
            SelectedSupplierForOrder = null;
            SelectedWarehouseForOrder = null;
            if (OrderQuantityTextBox != null)
                OrderQuantityTextBox.Text = "1";

            OrderDialogIsVisible = true;
        }

        private void ConfirmOrder_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(NewProductName) ||
                string.IsNullOrWhiteSpace(NewProductCategory) ||
                SelectedSupplierForOrder == null ||
                SelectedWarehouseForOrder == null ||
                !decimal.TryParse(OrderProductCostPriceTextBox.Text, out decimal costPrice) || costPrice <= 0 ||
                !decimal.TryParse(OrderProductPriceTextBox.Text, out decimal price) || price <= 0 ||
                !int.TryParse(OrderQuantityTextBox.Text, out int quantity) || quantity <= 0)
            {
                MessageBox.Show("Заполните все поля корректно!", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            // Создаем новый товар
            var newProduct = new Product
            {
                Category = NewProductCategory,
                Name = NewProductName,
                Price = price,
                CostPrice = costPrice,
                Quantity = quantity,
                WarehouseId = SelectedWarehouseForOrder.Id
            };

            DataManager.AddProduct(newProduct);

            // Создаем запись о закупке
            var purchase = new Purchase
            {
                ProductId = newProduct.Id,
                Quantity = quantity,
                TotalAmount = costPrice * quantity,
                PurchaseDate = System.DateTime.Now,
                SupplierId = SelectedSupplierForOrder.Id,
                WarehouseId = SelectedWarehouseForOrder.Id
            };

            DataManager.Purchases.Add(purchase);
            DataManager.SaveAllData();

            MessageBox.Show($"Заказ на товар '{NewProductName}' оформлен!\n" +
                           $"Поставщик: {SelectedSupplierForOrder.Name}\n" +
                           $"Количество: {quantity} шт.\n" +
                           $"Сумма: {purchase.TotalAmount} руб.",
                "Заказ оформлен", MessageBoxButton.OK, MessageBoxImage.Information);

            OrderDialogIsVisible = false;

            // Обновляем отображение
            OnPropertyChanged(nameof(Purchases));
        }

        private void CancelSearch_Click(object sender, RoutedEventArgs e) => SearchSuppliersDialogIsVisible = false;
        private void CancelOrder_Click(object sender, RoutedEventArgs e) => OrderDialogIsVisible = false;

        // Обновление суммы заказа при изменении количества
        private void OrderQuantityTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            OnPropertyChanged(nameof(OrderTotalAmount));
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}