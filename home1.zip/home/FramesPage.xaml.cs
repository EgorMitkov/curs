﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;

namespace home
{
    public partial class FramesPage : Page, INotifyPropertyChanged
    {
        private ObservableCollection<WorkSchedule> _workSchedule = new ObservableCollection<WorkSchedule>();
        private bool _addEmployeeDialogIsVisible;
        private bool _salaryCalculationDialogIsVisible;
        private bool _scheduleDialogIsVisible;
        private Employee _selectedEmployeeForSalary;
        private DateTime _selectedScheduleDate = DateTime.Today;

        public FramesPage()
        {
            InitializeComponent();
            LoadSchedule();
            DataContext = this;
        }

        public ObservableCollection<Employee> Employees => DataManager.Employees;
        public ObservableCollection<WorkSchedule> WorkScheduleForSelectedDate => _workSchedule;
        public string[] Positions => DataManager.Positions;
        public string[] Departments => DataManager.Departments;

        public bool AddEmployeeDialogIsVisible
        {
            get => _addEmployeeDialogIsVisible;
            set
            {
                _addEmployeeDialogIsVisible = value;
                OnPropertyChanged();
            }
        }

        public bool SalaryCalculationDialogIsVisible
        {
            get => _salaryCalculationDialogIsVisible;
            set
            {
                _salaryCalculationDialogIsVisible = value;
                OnPropertyChanged();
            }
        }

        public bool ScheduleDialogIsVisible
        {
            get => _scheduleDialogIsVisible;
            set
            {
                _scheduleDialogIsVisible = value;
                OnPropertyChanged();
            }
        }

        public Employee SelectedEmployeeForSalary
        {
            get => _selectedEmployeeForSalary;
            set
            {
                _selectedEmployeeForSalary = value;
                OnPropertyChanged();
                OnPropertyChanged(nameof(CalculatedSalary));
            }
        }

        public DateTime SelectedScheduleDate
        {
            get => _selectedScheduleDate;
            set
            {
                _selectedScheduleDate = value;
                OnPropertyChanged();
            }
        }

        public decimal CalculatedSalary
        {
            get
            {
                if (SelectedEmployeeForSalary != null && int.TryParse(WorkedDaysTextBox.Text, out int workedDays))
                {
                    return DataManager.CalculateSalary(SelectedEmployeeForSalary.Id, workedDays);
                }
                return 0;
            }
        }

        private const string ScheduleFilePath = @"C:\Users\user\Documents\home\bin\Debug\schedule.txt";

        private void LoadSchedule()
        {
            if (File.Exists(ScheduleFilePath))
            {
                _workSchedule.Clear();
                foreach (var line in File.ReadAllLines(ScheduleFilePath))
                {
                    var parts = line.Split(';');
                    if (parts.Length >= 4)
                    {
                        _workSchedule.Add(new WorkSchedule
                        {
                            EmployeeFullName = parts[0],
                            ShiftStartTime = TimeSpan.Parse(parts[1]),
                            ShiftEndTime = TimeSpan.Parse(parts[2]),
                            Date = DateTime.Parse(parts[3], CultureInfo.InvariantCulture)
                        });
                    }
                }
            }
            else
            {
                CreateTestSchedule();
            }
        }

        private void CreateTestSchedule()
        {
            var today = DateTime.Today;
            foreach (var employee in DataManager.Employees)
            {
                _workSchedule.Add(new WorkSchedule
                {
                    EmployeeFullName = employee.Name,
                    ShiftStartTime = new TimeSpan(9, 0, 0),
                    ShiftEndTime = new TimeSpan(18, 0, 0),
                    Date = today,
                    HoursWorked = 8
                });
            }
            SaveSchedule();
        }

        private void SaveSchedule()
        {
            var lines = _workSchedule.Select(s =>
                $"{s.EmployeeFullName};{s.ShiftStartTime};{s.ShiftEndTime};{s.Date:yyyy-MM-dd};{s.HoursWorked}");
            File.WriteAllLines(ScheduleFilePath, lines);
        }

        // Обработчики для кнопок действий
        private void AddEmployee_Click(object sender, RoutedEventArgs e)
        {
            AddEmployeeDialogIsVisible = true;
        }

        private void EmployeePerformanceDetails_Click(object sender, RoutedEventArgs e)
        {
            string performanceDetails = $"Система оценки сотрудников:\n\n" +
                                       $"KPI-based evaluation system\n\n" +
                                       $"Система мотивации:\nPerformance-based bonuses and career growth\n\n" +
                                       $"Всего сотрудников: {DataManager.Employees.Count}";

            MessageBox.Show(performanceDetails, "Оценка и мотивация", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void CalculateSalary_Click(object sender, RoutedEventArgs e)
        {
            if (EmployeesDataGrid.SelectedItem is Employee selectedEmployee)
            {
                SelectedEmployeeForSalary = selectedEmployee;
                SalaryCalculationDialogIsVisible = true;
            }
            else
            {
                MessageBox.Show("Выберите сотрудника для расчета зарплаты!", "Внимание",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void GenerateWorkSchedule_Click(object sender, RoutedEventArgs e)
        {
            ScheduleDialogIsVisible = true;
        }

        private void ConfirmAddEmployee_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(NewEmployeeNameTextBox.Text) ||
                NewEmployeePositionComboBox.SelectedItem == null ||
                NewEmployeeDepartmentComboBox.SelectedItem == null ||
                string.IsNullOrWhiteSpace(NewEmployeeSalaryTextBox.Text))
            {
                MessageBox.Show("Заполните все поля!", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            if (decimal.TryParse(NewEmployeeSalaryTextBox.Text, out decimal salary))
            {
                var newEmployee = new Employee
                {
                    Name = NewEmployeeNameTextBox.Text,
                    Position = NewEmployeePositionComboBox.SelectedItem.ToString(),
                    Department = NewEmployeeDepartmentComboBox.SelectedItem.ToString(),
                    Salary = salary,
                    WorkHours = 160 // Стандартная норма часов в месяц
                };

                DataManager.AddEmployee(newEmployee);

                // Очистка полей
                NewEmployeeNameTextBox.Text = "";
                NewEmployeeSalaryTextBox.Text = "";
                NewEmployeePositionComboBox.SelectedIndex = -1;
                NewEmployeeDepartmentComboBox.SelectedIndex = -1;

                AddEmployeeDialogIsVisible = false;
                MessageBox.Show("Сотрудник добавлен!", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else
            {
                MessageBox.Show("Введите корректную зарплату!", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ConfirmSalaryCalculation_Click(object sender, RoutedEventArgs e)
        {
            if (SelectedEmployeeForSalary != null && int.TryParse(WorkedDaysTextBox.Text, out int workedDays))
            {
                decimal salary = DataManager.CalculateSalary(SelectedEmployeeForSalary.Id, workedDays);
                MessageBox.Show($"Расчет зарплаты для {SelectedEmployeeForSalary.Name}:\n\n" +
                               $"Должность: {SelectedEmployeeForSalary.Position}\n" +
                               $"Оклад: {SelectedEmployeeForSalary.Salary:C}\n" +
                               $"Отработано дней: {workedDays}\n" +
                               $"Начислено: {salary:C}",
                    "Расчет зарплаты", MessageBoxButton.OK, MessageBoxImage.Information);

                SalaryCalculationDialogIsVisible = false;
            }
        }

        private void ConfirmScheduleGeneration_Click(object sender, RoutedEventArgs e)
        {
            if (ScheduleDatePicker.SelectedDate.HasValue)
            {
                SelectedScheduleDate = ScheduleDatePicker.SelectedDate.Value;

                // Генерация расписания на выбранную дату
                _workSchedule.Clear();

                foreach (var employee in DataManager.Employees)
                {
                    // Генерация случайного графика (9:00-18:00 или 10:00-19:00)
                    var random = new Random();
                    var startHour = random.Next(0, 2) == 0 ? 9 : 10;

                    _workSchedule.Add(new WorkSchedule
                    {
                        EmployeeFullName = employee.Name,
                        ShiftStartTime = new TimeSpan(startHour, 0, 0),
                        ShiftEndTime = new TimeSpan(startHour + 9, 0, 0), // 9-часовой рабочий день
                        Date = SelectedScheduleDate,
                        HoursWorked = 8
                    });
                }

                SaveSchedule();
                OnPropertyChanged(nameof(WorkScheduleForSelectedDate));

                MessageBox.Show($"График работы сгенерирован на {SelectedScheduleDate:dd.MM.yyyy}!", "Успех",
                    MessageBoxButton.OK, MessageBoxImage.Information);

                ScheduleDialogIsVisible = false;
            }
            else
            {
                MessageBox.Show("Выберите дату для генерации графика!", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void WorkedDaysTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            OnPropertyChanged(nameof(CalculatedSalary));
        }

        // Используем полное имя класса для устранения неоднозначности
        private void OnSelectedDateChanged(object sender, SelectionChangedEventArgs e)
        {
            System.Windows.Controls.Calendar calendar = sender as System.Windows.Controls.Calendar;
            if (calendar != null && calendar.SelectedDate.HasValue)
            {
                var selectedDate = calendar.SelectedDate.Value;
                UpdateWorkSchedule(selectedDate);
            }
        }

        private void UpdateWorkSchedule(DateTime date)
        {
            var scheduleForDate = _workSchedule
                .Where(s => s.Date.Date == date.Date)
                .ToList();

            _workSchedule.Clear();
            foreach (var schedule in scheduleForDate)
            {
                _workSchedule.Add(schedule);
            }

            OnPropertyChanged(nameof(WorkScheduleForSelectedDate));
        }

        private void CancelAddEmployee_Click(object sender, RoutedEventArgs e) => AddEmployeeDialogIsVisible = false;
        private void CancelSalaryCalculation_Click(object sender, RoutedEventArgs e) => SalaryCalculationDialogIsVisible = false;
        private void CancelScheduleGeneration_Click(object sender, RoutedEventArgs e) => ScheduleDialogIsVisible = false;

        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}