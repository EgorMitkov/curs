﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace home
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            // Загружаем все данные при запуске
            DataManager.LoadAllData();
            LoadInitialPage();
        }

        private void LoadInitialPage()
        {
            ContentFrame.Navigate(new WelcomePage());
        }

        // Обработчики навигации остаются без изменений
        private void NavigateToCatalog_Click(object sender, RoutedEventArgs e)
        {
            ContentFrame.Navigate(new CatalogPage());
        }

        private void NavigateToWarehouse_Click(object sender, RoutedEventArgs e)
        {
            ContentFrame.Navigate(new WarehousePage());
        }

        private void NavigateToPurchases_Click(object sender, RoutedEventArgs e)
        {
            ContentFrame.Navigate(new PurchasesPage());
        }

        private void NavigateToFinance_Click(object sender, RoutedEventArgs e)
        {
            ContentFrame.Navigate(new FinancePage());
        }

        private void NavigateToClient_Click(object sender, RoutedEventArgs e)
        {
            ContentFrame.Navigate(new ClientPage());
        }

        private void NavigateToFrames_Click(object sender, RoutedEventArgs e)
        {
            ContentFrame.Navigate(new FramesPage());
        }

        private void NavigateToAnalytics_Click(object sender, RoutedEventArgs e)
        {
            ContentFrame.Navigate(new AnalyticsPage());
        }

        protected override void OnClosing(System.ComponentModel.CancelEventArgs e)
        {
            // Сохраняем все данные при закрытии приложения
            DataManager.SaveAllData();
            base.OnClosing(e);
        }

        private void NavigateToSales_Click(object sender, RoutedEventArgs e)
        {
            ContentFrame.Navigate(new SalesPage());
        }

        private void NavigateToСlient_Click(object sender, RoutedEventArgs e)
        {
            ContentFrame.Navigate(new ClientPage());
        }
    }
}