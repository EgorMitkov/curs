﻿using System;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;

namespace home
{
    public partial class FinancePage : Page, INotifyPropertyChanged
    {
        private DateTime _startDate = DateTime.Now.AddMonths(-1);
        private DateTime _endDate = DateTime.Now;

        public FinancePage()
        {
            InitializeComponent();
            DataContext = this;
        }

        // Финансовые показатели на основе реальных данных
        public decimal Revenue => DataManager.GetTotalRevenue(_startDate, _endDate);
        public decimal Expenses => DataManager.GetTotalExpenses(_startDate, _endDate);
        public decimal Profit => Revenue - Expenses;
        public decimal TaxAmount => Profit > 0 ? Profit * 0.2m : 0; // 20% налог на прибыль
        public decimal PurchaseCosts => DataManager.GetTotalPurchaseCost(_startDate, _endDate);
        public decimal SalaryCosts => DataManager.GetTotalSalaryCost();
        public decimal NetProfit => Profit - TaxAmount;

        public string BalanceSheet =>
            $"Активы: {GetTotalAssets()} руб., Пассивы: {GetTotalLiabilities()} руб.";

        private decimal GetTotalAssets()
        {
            // Активы = товары на складах + денежные средства (выручка)
            decimal inventoryValue = DataManager.Products.Sum(p => p.CostPrice * p.Quantity);
            decimal cash = Revenue * 0.3m; // Предполагаем, что 30% выручки в кассе
            return inventoryValue + cash;
        }

        private decimal GetTotalLiabilities()
        {
            // Пассивы = закупки в кредит + налоги
            decimal creditPurchases = PurchaseCosts * 0.2m; // 20% закупок в кредит
            return creditPurchases + TaxAmount;
        }

        // Обработчики для кнопок действий
        private void ShowRevenueExpensesDetail_Click(object sender, RoutedEventArgs e)
        {
            int productsSold = DataManager.GetTotalProductsSold(_startDate, _endDate);
            int productsPurchased = DataManager.GetTotalProductsPurchased(_startDate, _endDate);
            decimal averageSale = DataManager.GetAverageSaleAmount(_startDate, _endDate);

            string details = $"Детальная финансовая сводка за период {_startDate:dd.MM.yyyy} - {_endDate:dd.MM.yyyy}:\n\n" +
                            $"Выручка от продаж: {Revenue} руб.\n" +
                            $"Расходы: {Expenses} руб.\n" +
                            $" - Закупки: {PurchaseCosts} руб.\n" +
                            $" - Зарплаты: {SalaryCosts} руб.\n" +
                            $"Прибыль: {Profit} руб.\n" +
                            $"Налоги: {TaxAmount} руб.\n" +
                            $"Чистая прибыль: {NetProfit} руб.\n" +
                            $"Рентабельность: {(Revenue > 0 ? (Profit / Revenue) * 100 : 0):F1}%\n\n" +
                            $"Продано товаров: {productsSold} шт.\n" +
                            $"Закуплено товаров: {productsPurchased} шт.\n" +
                            $"Средний чек: {averageSale:F0} руб.";

            MessageBox.Show(details, "Финансовая сводка", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void ShowTaxesPaymentsDetail_Click(object sender, RoutedEventArgs e)
        {
            decimal vat = Revenue * 0.2m; // НДС 20%
            decimal socialContributions = SalaryCosts * 0.3m; // Социальные взносы 30%

            string details = $"Налоги и платежи за период {_startDate:dd.MM.yyyy} - {_endDate:dd.MM.yyyy}:\n\n" +
                            $"НДС: {vat} руб.\n" +
                            $"Налог на прибыль: {TaxAmount} руб.\n" +
                            $"Социальные взносы: {socialContributions} руб.\n" +
                            $"Итого налогов: {vat + TaxAmount + socialContributions} руб.";

            MessageBox.Show(details, "Налоги и платежи", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void ShowAccountingReport_Click(object sender, RoutedEventArgs e)
        {
            decimal currentAssets = GetTotalAssets();
            decimal fixedAssets = currentAssets * 0.6m; // Основные средства
            decimal totalAssets = currentAssets + fixedAssets;

            string report = $"Бухгалтерская отчетность на {DateTime.Now:dd.MM.yyyy}:\n\n" +
                           $"{BalanceSheet}\n" +
                           $"Оборотные активы: {currentAssets} руб.\n" +
                           $"Внеоборотные активы: {fixedAssets} руб.\n" +
                           $"Всего активов: {totalAssets} руб.\n" +
                           $"Собственный капитал: {totalAssets - GetTotalLiabilities()} руб.";

            MessageBox.Show(report, "Бухгалтерская отчетность", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void ShowSalaryDetails_Click(object sender, RoutedEventArgs e)
        {
            decimal totalSalary = DataManager.Employees.Sum(emp => emp.Salary);
            decimal avgSalary = DataManager.Employees.Any() ?
                totalSalary / DataManager.Employees.Count : 0;

            string salaryDetails = $"Фонд оплаты труда:\n\n" +
                                  $"Общий фонд: {totalSalary} руб./мес.\n" +
                                  $"Количество сотрудников: {DataManager.Employees.Count}\n" +
                                  $"Средняя зарплата: {avgSalary:F0} руб.\n\n" +
                                  $"Распределение по отделам:\n";

            var deptSalaries = DataManager.Employees
                .GroupBy(emp => emp.Department)
                .Select(g => new { Department = g.Key, TotalSalary = g.Sum(emp => emp.Salary) });

            foreach (var dept in deptSalaries)
            {
                salaryDetails += $"- {dept.Department}: {dept.TotalSalary} руб.\n";
            }

            MessageBox.Show(salaryDetails, "Зарплаты и премии", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void GenerateReport_Click(object sender, RoutedEventArgs e)
        {
            int uniqueCustomers = DataManager.GetUniqueCustomersCount(_startDate, _endDate);
            var topProducts = DataManager.GetTopSellingProducts(_startDate, _endDate, 3);

            string topProductsList = topProducts.Any() ?
                string.Join("\n", topProducts.Select(p => $"- {p.Name}: {p.Quantity} шт. в наличии")) :
                "Нет данных о продажах";

            string report = $"Финансовый отчет\n" +
                           $"Период: {_startDate:dd.MM.yyyy} - {_endDate:dd.MM.yyyy}\n\n" +
                           $"ВЫРУЧКА И РАСХОДЫ:\n" +
                           $"Выручка: {Revenue} руб.\n" +
                           $"Расходы: {Expenses} руб.\n" +
                           $"Прибыль: {Profit} руб.\n" +
                           $"Налоги: {TaxAmount} руб.\n" +
                           $"Чистая прибыль: {NetProfit} руб.\n\n" +
                           $"ПОКАЗАТЕЛИ ЭФФЕКТИВНОСТИ:\n" +
                           $"Уникальных клиентов: {uniqueCustomers}\n" +
                           $"Рентабельность: {(Revenue > 0 ? (Profit / Revenue) * 100 : 0):F1}%\n\n" +
                           $"ПОПУЛЯРНЫЕ ТОВАРЫ:\n{topProductsList}\n\n" +
                           $"Сгенерировано: {DateTime.Now:dd.MM.yyyy HH:mm}";

            MessageBox.Show(report, "Финансовый отчет", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}