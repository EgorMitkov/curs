﻿using System;
using System.Collections.ObjectModel;
using System.Linq;

namespace home
{
    public class Product
    {
        public int Id { get; set; }
        public string Category { get; set; }
        public string Name { get; set; }
        public decimal Price { get; set; }
        public decimal CostPrice { get; set; }
        public int Quantity { get; set; }
        public int WarehouseId { get; set; }

        // Свойство только для отображения адреса склада
        public string WarehouseAddress
        {
            get
            {
                try
                {
                    var warehouse = DataManager.Warehouses.FirstOrDefault(w => w.Id == WarehouseId);
                    return warehouse?.Address ?? $"Склад ID: {WarehouseId}";
                }
                catch
                {
                    return $"Склад ID: {WarehouseId}";
                }
            }
        }
    }

    public class Warehouse
    {
        public int Id { get; set; }
        public string Address { get; set; }
        public int MaxCapacity { get; set; }
        public int CurrentQuantity { get; set; }

        public int FreeSpace => MaxCapacity - CurrentQuantity;
    }

    public class Supplier
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Contact { get; set; }
        public double Rating { get; set; }
    }

    public class Customer
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
    }

    public class Employee
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Position { get; set; }
        public string Department { get; set; }
        public decimal Salary { get; set; }
        public int WorkHours { get; set; } // Норма часов в месяц
    }

    public class Sale
    {
        public int Id { get; set; }
        public int ProductId { get; set; }
        public int Quantity { get; set; }
        public decimal TotalAmount { get; set; }
        public DateTime SaleDate { get; set; }
        public int CustomerId { get; set; }

        // Вычисляемые свойства для отображения
        public string ProductName
        {
            get
            {
                var product = DataManager.Products.FirstOrDefault(p => p.Id == ProductId);
                return product?.Name ?? $"Товар ID: {ProductId}";
            }
        }

        public string CustomerName
        {
            get
            {
                var customer = DataManager.Customers.FirstOrDefault(c => c.Id == CustomerId);
                return customer?.Name ?? $"Клиент ID: {CustomerId}";
            }
        }
    }

    public class Purchase
    {
        public int Id { get; set; }
        public int ProductId { get; set; }
        public int Quantity { get; set; }
        public decimal TotalAmount { get; set; }
        public DateTime PurchaseDate { get; set; }
        public int SupplierId { get; set; }
        public int WarehouseId { get; set; }

        // Вычисляемые свойства для отображения
        public string ProductName
        {
            get
            {
                var product = DataManager.Products.FirstOrDefault(p => p.Id == ProductId);
                return product?.Name ?? $"Товар ID: {ProductId}";
            }
        }

        public string SupplierName
        {
            get
            {
                var supplier = DataManager.Suppliers.FirstOrDefault(s => s.Id == SupplierId);
                return supplier?.Name ?? $"Поставщик ID: {SupplierId}";
            }
        }

        public string WarehouseAddress
        {
            get
            {
                var warehouse = DataManager.Warehouses.FirstOrDefault(w => w.Id == WarehouseId);
                return warehouse?.Address ?? $"Склад ID: {WarehouseId}";
            }
        }
    }

    public class TransferRecord
    {
        public int FromWarehouseId { get; set; }
        public int ToWarehouseId { get; set; }
        public int ProductId { get; set; }
        public int QuantityMoved { get; set; }
    }

    public class CustomerProfile
    {
        public string FullName { get; set; }
        public string EmailAddress { get; set; }
        public string PhoneNumber { get; set; }
        public string Region { get; set; }
    }

    public class WorkSchedule
    {
        public string EmployeeFullName { get; set; }
        public TimeSpan ShiftStartTime { get; set; }
        public TimeSpan ShiftEndTime { get; set; }
        public DateTime Date { get; set; }
        public int HoursWorked { get; set; }
    }

    public class FinancialData
    {
        public decimal Revenue { get; set; }
        public decimal Expenses { get; set; }
        public decimal TaxAmount { get; set; }
        public decimal RentAndServicesPayment { get; set; }
        public string BalanceSheet { get; set; } = "Активы: 0, Пассивы: 0";
        public string AnnualReports { get; set; } = "Годовой отчет 2024";
        public decimal SalaryFund { get; set; }
        public decimal BonusFund { get; set; }
    }

    public class AnalyticsData
    {
        public decimal CompanyIncome { get; set; } = 1000000m;
        public decimal CompanyExpenses { get; set; } = 600000m;
        public decimal OperatingProfit { get; set; } = 400000m;
        public decimal TurnoverLastQuarter { get; set; } = 500000m;
        public decimal ProfitMargin { get; set; } = 0.2m;
        public decimal AverageProductPrice { get; set; } = 1500m;
        public decimal SalesVolumeNextQuarter { get; set; } = 550000m;
        public decimal PotentialProfitNextQuarter { get; set; } = 450000m;
        public decimal PredictedAverageProductPrice { get; set; } = 1600m;
        public decimal AdvertisingCost { get; set; } = 50000m;
        public decimal ROI { get; set; } = 2.5m;
        public int AttractedCustomersCount { get; set; } = 150;
    }
}