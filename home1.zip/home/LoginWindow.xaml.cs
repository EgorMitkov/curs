﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input; // Добавьте эту строку если используете Key events

namespace home
{
    public partial class LoginWindow : Window
    {
        public LoginWindow()
        {
            InitializeComponent();
            // Инициализируем файл авторизации
            AuthManager.InitializeAuth();
            UsernameTextBox.Focus();
        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            string username = UsernameTextBox.Text.Trim();
            string password = PasswordBox.Password;

            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                ShowErrorMessage("Введите логин и пароль");
                return;
            }

            // Аутентификация через txt файл
            if (AuthManager.Authenticate(username, password))
            {
                // Загружаем данные при успешной авторизации
                DataManager.LoadAllData();

                // Открываем главное окно
                MainWindow mainWindow = new MainWindow();
                if (AuthManager.CurrentUser != null)
                {
                    mainWindow.Title = $"Складская система - {AuthManager.CurrentUser.FullName}";
                }
                mainWindow.Show();

                // Закрываем окно авторизации
                this.Close();
            }
            else
            {
                ShowErrorMessage("Неверный логин или пароль");
                PasswordBox.Password = "";
                PasswordBox.Focus();
            }
        }

        private void ShowErrorMessage(string message)
        {
            ErrorMessageText.Text = message;
            ErrorMessageBorder.Visibility = Visibility.Visible;
        }

        // Обработка нажатия Enter в полях ввода
        private void UsernameTextBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                PasswordBox.Focus();
            }
        }

        private void PasswordBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                LoginButton_Click(sender, e);
            }
        }

        private void CloseErrorMessage_Click(object sender, MouseButtonEventArgs e)
        {
            ErrorMessageBorder.Visibility = Visibility.Collapsed;
        }
    }
}