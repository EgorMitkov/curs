﻿using System;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;

namespace home
{
    public partial class AnalyticsPage : Page, INotifyPropertyChanged
    {
        private DateTime _startDate = DateTime.Now.AddMonths(-1);
        private DateTime _endDate = DateTime.Now;

        public AnalyticsPage()
        {
            InitializeComponent();
            DataContext = this;
        }

        // Свойства для привязки данных на основе реальных данных
        public decimal CompanyIncome => DataManager.GetTotalRevenue(_startDate, _endDate);
        public decimal CompanyExpenses => DataManager.GetTotalExpenses(_startDate, _endDate);
        public decimal OperatingProfit => CompanyIncome - CompanyExpenses;

        public decimal TurnoverLastQuarter =>
            DataManager.GetTotalRevenue(DateTime.Now.AddMonths(-3), DateTime.Now);

        public decimal ProfitMargin => CompanyIncome > 0 ? OperatingProfit / CompanyIncome : 0;

        public decimal AverageProductPrice =>
            DataManager.Products.Any() ? DataManager.Products.Average(p => p.Price) : 0;

        public decimal SalesVolumeNextQuarter => CalculateSalesForecast();
        public decimal PotentialProfitNextQuarter => SalesVolumeNextQuarter * ProfitMargin;
        public decimal PredictedAverageProductPrice => AverageProductPrice * 1.05m; // +5%

        public decimal AdvertisingCost => 50000m;
        public decimal ROI => CompanyIncome > 0 ? (CompanyIncome - CompanyExpenses) / AdvertisingCost : 0;
        public int AttractedCustomersCount => DataManager.GetUniqueCustomersCount(_startDate, _endDate);

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        private decimal CalculateSalesForecast()
        {
            decimal currentSales = CompanyIncome;
            decimal growthRate = 0.1m;

            var previousPeriodSales = DataManager.GetTotalRevenue(
                _startDate.AddMonths(-1), _endDate.AddMonths(-1));

            if (previousPeriodSales > 0)
            {
                growthRate = (currentSales - previousPeriodSales) / previousPeriodSales;
            }

            return currentSales * (1 + Math.Max(growthRate, 0.05m));
        }

        private void ShowFinancialAnalytics_Click(object sender, RoutedEventArgs e)
        {
            var topProducts = DataManager.GetTopSellingProducts(_startDate, _endDate, 5);
            decimal avgSale = DataManager.GetAverageSaleAmount(_startDate, _endDate);

            string topProductsList = topProducts.Any() ?
                string.Join("\n", topProducts.Select(p => $"- {p.Name}: {p.Price} руб. (остаток: {p.Quantity} шт.)")) :
                "Нет данных о продажах";

            string analytics = $"Финансовая аналитика за период {_startDate:dd.MM.yyyy} - {_endDate:dd.MM.yyyy}:\n\n" +
                              $"Общий доход: {CompanyIncome} руб.\n" +
                              $"Общие расходы: {CompanyExpenses} руб.\n" +
                              $"Операционная прибыль: {OperatingProfit} руб.\n" +
                              $"Оборот за квартал: {TurnoverLastQuarter} руб.\n" +
                              $"Рентабельность: {ProfitMargin:P1}\n" +
                              $"Средний чек: {avgSale:F0} руб.\n" +
                              $"Уникальных клиентов: {AttractedCustomersCount}\n\n" +
                              $"ТОП-5 товаров по цене:\n{topProductsList}";

            MessageBox.Show(analytics, "Финансовая аналитика", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void ShowSalesForecast_Click(object sender, RoutedEventArgs e)
        {
            decimal growthRate = CompanyIncome > 0 ? (SalesVolumeNextQuarter - CompanyIncome) / CompanyIncome : 0;

            string recommendation;
            if (growthRate > 0.15m)
                recommendation = "Высокий рост - увеличить запасы";
            else if (growthRate > 0.05m)
                recommendation = "Стабильный рост";
            else
                recommendation = "Рассмотреть акции для стимулирования продаж";

            string forecast = "Прогноз продаж на следующий квартал:\n\n" +
                             $"Текущий оборот: {CompanyIncome} руб.\n" +
                             $"Ожидаемый объем продаж: {SalesVolumeNextQuarter} руб.\n" +
                             $"Потенциальная прибыль: {PotentialProfitNextQuarter} руб.\n" +
                             $"Прогноз средней цены: {PredictedAverageProductPrice} руб.\n" +
                             $"Ожидаемый рост: {growthRate:P1}\n\n" +
                             $"Рекомендации: {recommendation}";

            MessageBox.Show(forecast, "Прогноз продаж", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void ShowEfficiencyAnalysis_Click(object sender, RoutedEventArgs e)
        {
            decimal customerAcquisitionCost = AdvertisingCost / Math.Max(AttractedCustomersCount, 1);
            decimal customerLifetimeValue = CompanyIncome / Math.Max(AttractedCustomersCount, 1);

            string efficiencyLevel;
            if (ROI > 3)
                efficiencyLevel = "Очень высокая";
            else if (ROI > 2)
                efficiencyLevel = "Высокая";
            else if (ROI > 1)
                efficiencyLevel = "Средняя";
            else
                efficiencyLevel = "Низкая";

            string recommendation = ROI < 1 ? "Пересмотреть рекламную стратегию" : "Продолжать текущую стратегию";

            string efficiency = $"Анализ эффективности за период {_startDate:dd.MM.yyyy} - {_endDate:dd.MM.yyyy}:\n\n" +
                               $"Затраты на маркетинг: {AdvertisingCost} руб.\n" +
                               $"ROI (окупаемость инвестиций): {ROI:F1}\n" +
                               $"Привлечено новых клиентов: {AttractedCustomersCount}\n" +
                               $"Стоимость привлечения клиента: {customerAcquisitionCost:F0} руб.\n" +
                               $"Пожизненная ценность клиента: {customerLifetimeValue:F0} руб.\n" +
                               $"Эффективность рекламы: {efficiencyLevel}\n\n" +
                               $"Рекомендации: {recommendation}";

            MessageBox.Show(efficiency, "Анализ эффективности", MessageBoxButton.OK, MessageBoxImage.Information);
        }
    }
}