﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;

namespace home
{
    public partial class SalesPage : Page, INotifyPropertyChanged
    {
        private bool _addSaleDialogIsVisible;
        private Product _selectedProductForSale;
        private Customer _selectedCustomerForSale;
        private ObservableCollection<Product> _availableProducts;

        public SalesPage()
        {
            InitializeComponent();
            DataContext = this;
            UpdateAvailableProducts();
        }

        public ObservableCollection<Sale> Sales => DataManager.Sales;
        public ObservableCollection<Customer> Customers => DataManager.Customers;

        public ObservableCollection<Product> AvailableProducts
        {
            get => _availableProducts;
            set
            {
                _availableProducts = value;
                OnPropertyChanged();
            }
        }

        public bool AddSaleDialogIsVisible
        {
            get => _addSaleDialogIsVisible;
            set
            {
                _addSaleDialogIsVisible = value;
                OnPropertyChanged();
            }
        }

        public Product SelectedProductForSale
        {
            get => _selectedProductForSale;
            set
            {
                _selectedProductForSale = value;
                OnPropertyChanged();
                OnPropertyChanged(nameof(SelectedProductPrice));
                OnPropertyChanged(nameof(SelectedProductQuantity));
                OnPropertyChanged(nameof(SaleTotalAmount));
            }
        }

        public Customer SelectedCustomerForSale
        {
            get => _selectedCustomerForSale;
            set
            {
                _selectedCustomerForSale = value;
                OnPropertyChanged();
            }
        }

        public decimal SelectedProductPrice => SelectedProductForSale?.Price ?? 0;
        public int SelectedProductQuantity => SelectedProductForSale?.Quantity ?? 0;

        public decimal SaleTotalAmount
        {
            get
            {
                if (SelectedProductForSale != null && int.TryParse(SaleQuantityTextBox?.Text, out int quantity))
                {
                    return SelectedProductForSale.Price * quantity;
                }
                return 0;
            }
        }

        private void UpdateAvailableProducts()
        {
            var available = DataManager.Products.Where(p => p.Quantity > 0).ToList();
            AvailableProducts = new ObservableCollection<Product>(available);
        }

        private void AddSale_Click(object sender, RoutedEventArgs e)
        {
            if (!DataManager.Products.Any(p => p.Quantity > 0))
            {
                MessageBox.Show("Нет доступных товаров для продажи!", "Внимание",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (!DataManager.Customers.Any())
            {
                MessageBox.Show("Нет зарегистрированных клиентов!", "Внимание",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            // Сброс выбора при открытии диалога
            SelectedProductForSale = AvailableProducts.FirstOrDefault();
            SelectedCustomerForSale = Customers.FirstOrDefault();
            if (SaleQuantityTextBox != null)
                SaleQuantityTextBox.Text = "1";

            AddSaleDialogIsVisible = true;
        }

        private void ConfirmSale_Click(object sender, RoutedEventArgs e)
        {
            if (SelectedProductForSale == null || SelectedCustomerForSale == null)
            {
                MessageBox.Show("Выберите товар и клиента!", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            if (!int.TryParse(SaleQuantityTextBox.Text, out int quantity) || quantity <= 0)
            {
                MessageBox.Show("Введите корректное количество!", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            if (SelectedProductForSale.Quantity < quantity)
            {
                MessageBox.Show($"Недостаточно товара на складе! Доступно: {SelectedProductForSale.Quantity} шт.",
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            try
            {
                var sale = new Sale
                {
                    ProductId = SelectedProductForSale.Id,
                    Quantity = quantity,
                    TotalAmount = SelectedProductForSale.Price * quantity,
                    SaleDate = DateTime.Now,
                    CustomerId = SelectedCustomerForSale.Id
                };

                // Добавляем продажу через DataManager
                DataManager.AddSale(sale);

                MessageBox.Show($"Продажа оформлена!\n\n" +
                               $"Товар: {SelectedProductForSale.Name}\n" +
                               $"Количество: {quantity} шт.\n" +
                               $"Сумма: {sale.TotalAmount} руб.\n" +
                               $"Клиент: {SelectedCustomerForSale.Name}",
                    "Успех", MessageBoxButton.OK, MessageBoxImage.Information);

                AddSaleDialogIsVisible = false;

                // Обновляем доступные товары
                UpdateAvailableProducts();

                // Обновляем отображение
                OnPropertyChanged(nameof(Sales));
                OnPropertyChanged(nameof(AvailableProducts));
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при оформлении продажи: {ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ShowSalesStats_Click(object sender, RoutedEventArgs e)
        {
            decimal totalSales = DataManager.Sales.Sum(s => s.TotalAmount);
            int totalItems = DataManager.Sales.Sum(s => s.Quantity);
            int totalTransactions = DataManager.Sales.Count;

            var popularProducts = DataManager.Sales
                .GroupBy(s => s.ProductId)
                .Select(g => new
                {
                    Product = DataManager.GetProduct(g.Key),
                    TotalQuantity = g.Sum(s => s.Quantity),
                    TotalAmount = g.Sum(s => s.TotalAmount)
                })
                .Where(x => x.Product != null)
                .OrderByDescending(x => x.TotalQuantity)
                .Take(3)
                .ToList();

            string popularList = popularProducts.Any() ?
                string.Join("\n", popularProducts.Select(p => $"- {p.Product.Name}: {p.TotalQuantity} шт. ({p.TotalAmount} руб.)")) :
                "Нет данных о продажах";

            MessageBox.Show($"Статистика продаж:\n\n" +
                           $"Всего продаж: {totalTransactions}\n" +
                           $"Общая выручка: {totalSales} руб.\n" +
                           $"Продано товаров: {totalItems} шт.\n" +
                           $"Средний чек: {(totalTransactions > 0 ? totalSales / totalTransactions : 0):F0} руб.\n\n" +
                           $"Популярные товары:\n{popularList}",
                           "Статистика продаж", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void SaleQuantityTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            OnPropertyChanged(nameof(SaleTotalAmount));
        }

        private void CancelSale_Click(object sender, RoutedEventArgs e)
        {
            AddSaleDialogIsVisible = false;
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}