﻿using System;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;

namespace home
{
    public partial class WarehousePage : Page, INotifyPropertyChanged
    {
        private bool _moveGoodsDialogIsVisible;
        private bool _inventoryDialogIsVisible;
        private Product _selectedProductForTransfer;
        private Warehouse _selectedFromWarehouse;
        private Warehouse _selectedToWarehouse;

        public WarehousePage()
        {
            InitializeComponent();
            DataContext = this;
        }

        public System.Collections.ObjectModel.ObservableCollection<Warehouse> Warehouses => DataManager.Warehouses;
        public System.Collections.ObjectModel.ObservableCollection<Product> Products => DataManager.Products;

        public bool MoveGoodsDialogIsVisible
        {
            get => _moveGoodsDialogIsVisible;
            set
            {
                _moveGoodsDialogIsVisible = value;
                OnPropertyChanged();
            }
        }

        public bool InventoryDialogIsVisible
        {
            get => _inventoryDialogIsVisible;
            set
            {
                _inventoryDialogIsVisible = value;
                OnPropertyChanged();
            }
        }

        public Product SelectedProductForTransfer
        {
            get => _selectedProductForTransfer;
            set
            {
                _selectedProductForTransfer = value;
                OnPropertyChanged();
            }
        }

        public Warehouse SelectedFromWarehouse
        {
            get => _selectedFromWarehouse;
            set
            {
                _selectedFromWarehouse = value;
                OnPropertyChanged();
                UpdateProductsForTransfer();
            }
        }

        public Warehouse SelectedToWarehouse
        {
            get => _selectedToWarehouse;
            set
            {
                _selectedToWarehouse = value;
                OnPropertyChanged();
            }
        }

        // Обработчики для кнопок действий
        private void MoveGoods_Click(object sender, RoutedEventArgs e)
        {
            MoveGoodsDialogIsVisible = true;
        }

        private void ConductInventory_Click(object sender, RoutedEventArgs e)
        {
            InventoryDialogIsVisible = true;
        }

        private void ConfirmTransfer_Click(object sender, RoutedEventArgs e)
        {
            if (SelectedFromWarehouse != null && SelectedToWarehouse != null &&
                SelectedProductForTransfer != null &&
                int.TryParse(TransferQuantityTextBox.Text, out int quantity) && quantity > 0)
            {
                if (SelectedFromWarehouse.Id == SelectedToWarehouse.Id)
                {
                    MessageBox.Show("Нельзя перемещать товары на тот же склад!", "Ошибка",
                        MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                if (SelectedProductForTransfer.Quantity < quantity)
                {
                    MessageBox.Show($"Недостаточно товара на складе! Доступно: {SelectedProductForTransfer.Quantity} шт.",
                        "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                if (SelectedToWarehouse.FreeSpace < quantity)
                {
                    MessageBox.Show($"Недостаточно места на складе-получателе! Свободно: {SelectedToWarehouse.FreeSpace} шт.",
                        "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                try
                {
                    var transfer = new TransferRecord
                    {
                        FromWarehouseId = SelectedFromWarehouse.Id,
                        ToWarehouseId = SelectedToWarehouse.Id,
                        ProductId = SelectedProductForTransfer.Id,
                        QuantityMoved = quantity
                    };

                    DataManager.AddTransfer(transfer);

                    MessageBox.Show($"Товар '{SelectedProductForTransfer.Name}' перемещен со склада '{SelectedFromWarehouse.Address}' на склад '{SelectedToWarehouse.Address}' в количестве {quantity} шт.!",
                        "Успех", MessageBoxButton.OK, MessageBoxImage.Information);

                    MoveGoodsDialogIsVisible = false;

                    // Обновляем отображение
                    OnPropertyChanged(nameof(Products));
                    OnPropertyChanged(nameof(Warehouses));
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при перемещении товара: {ex.Message}", "Ошибка",
                        MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            else
            {
                MessageBox.Show("Заполните все поля корректно!", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ConfirmInventory_Click(object sender, RoutedEventArgs e)
        {
            int totalProducts = DataManager.Products.Sum(p => p.Quantity);
            int totalWarehouseCapacity = DataManager.Warehouses.Sum(w => w.CurrentQuantity);
            int totalCapacity = DataManager.Warehouses.Sum(w => w.MaxCapacity);
            int totalFreeSpace = DataManager.Warehouses.Sum(w => w.FreeSpace);

            var lowStockProducts = DataManager.GetLowStockProducts();
            string lowStockMessage = lowStockProducts.Any() ?
                $"\n\nТовары с низким запасом:\n{string.Join("\n", lowStockProducts.Select(p => $"- {p.Name}: {p.Quantity} шт."))}" :
                "\n\nВсе товары в достаточном количестве";

            MessageBox.Show($"Инвентаризация проведена!\n\n" +
                           $"Общее количество товаров: {totalProducts} шт.\n" +
                           $"Заполненность складов: {totalWarehouseCapacity} из {totalCapacity}\n" +
                           $"Свободное место: {totalFreeSpace} шт.\n" +
                           $"Заполненность: {(double)totalWarehouseCapacity / totalCapacity * 100:F1}%{lowStockMessage}",
                "Инвентаризация", MessageBoxButton.OK, MessageBoxImage.Information);

            InventoryDialogIsVisible = false;
        }

        private void UpdateProductsForTransfer()
        {
            if (SelectedFromWarehouse != null)
            {
                // Фильтруем товары по выбранному складу-отправителю
                var productsOnWarehouse = DataManager.Products
                    .Where(p => p.WarehouseId == SelectedFromWarehouse.Id && p.Quantity > 0)
                    .ToList();

                TransferProductComboBox.ItemsSource = productsOnWarehouse;
                TransferProductComboBox.SelectedIndex = productsOnWarehouse.Any() ? 0 : -1;
            }
        }

        private void CancelTransfer_Click(object sender, RoutedEventArgs e) => MoveGoodsDialogIsVisible = false;
        private void CancelInventory_Click(object sender, RoutedEventArgs e) => InventoryDialogIsVisible = false;

        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}