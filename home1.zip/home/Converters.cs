﻿using System;
using System.Globalization;
using System.Linq;
using System.Windows.Data;

namespace home
{
    public class WarehouseAddressConverter : IValueConverter
    {
        public static WarehouseAddressConverter Instance { get; } = new WarehouseAddressConverter();

        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is int warehouseId)
            {
                var warehouse = DataManager.Warehouses.FirstOrDefault(w => w.Id == warehouseId);
                return warehouse?.Address ?? $"Склад ID: {warehouseId}";
            }
            return "Неизвестный склад";
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}