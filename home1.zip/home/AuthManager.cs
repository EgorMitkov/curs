﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;

namespace home
{
    public static class AuthManager
    {
        private static string BasePath = @"C:\Users\user\Documents\home\bin\Debug";
        private static string AuthFilePath => Path.Combine(BasePath, "auth.txt");

        public static void InitializeAuth()
        {
            if (!File.Exists(AuthFilePath))
            {
                CreateDefaultAuthFile();
            }
        }

        private static void CreateDefaultAuthFile()
        {
            Directory.CreateDirectory(BasePath);
            var defaultUsers = new[]
            {
                "admin;admin;Администратор",
                "manager;manager;Менеджер",
                "user;user;Пользователь"
            };
            File.WriteAllLines(AuthFilePath, defaultUsers);
        }

        public static bool Authenticate(string username, string password)
        {
            try
            {
                if (!File.Exists(AuthFilePath))
                    return false;

                var lines = File.ReadAllLines(AuthFilePath);
                foreach (var line in lines)
                {
                    var parts = line.Split(';');
                    if (parts.Length >= 3)
                    {
                        var savedUsername = parts[0].Trim();
                        var savedPassword = parts[1].Trim();
                        var fullName = parts[2].Trim();

                        if (savedUsername == username && savedPassword == password)
                        {
                            CurrentUser = new { Username = username, FullName = fullName };
                            return true;
                        }
                    }
                }
                return false;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка авторизации: {ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }
        }

        public static dynamic CurrentUser { get; private set; }
    }
}