﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Windows;

namespace home
{
    public static class DataManager
    {
        // Пути к файлам
        public static string BasePath = @"C:\Users\user\Documents\home\bin\Debug";

        // Общие коллекции данных
        public static ObservableCollection<Product> Products { get; } = new ObservableCollection<Product>();
        public static ObservableCollection<Warehouse> Warehouses { get; } = new ObservableCollection<Warehouse>();
        public static ObservableCollection<Supplier> Suppliers { get; } = new ObservableCollection<Supplier>();
        public static ObservableCollection<Customer> Customers { get; } = new ObservableCollection<Customer>();
        public static ObservableCollection<Employee> Employees { get; } = new ObservableCollection<Employee>();
        public static ObservableCollection<Sale> Sales { get; } = new ObservableCollection<Sale>();
        public static ObservableCollection<Purchase> Purchases { get; } = new ObservableCollection<Purchase>();
        public static ObservableCollection<TransferRecord> TransferRecords { get; } = new ObservableCollection<TransferRecord>();

        // Стандартные категории
        public static string[] Categories => new[]
        {
            "Электроника",
            "Одежда",
            "Продукты питания",
            "Хозяйственные товары",
            "Медицинские изделия",
            "Строительные материалы"
        };

        // Должности
        public static string[] Positions => new[]
        {
            "Менеджер по продажам",
            "Маркетолог",
            "Бухгалтер",
            "Логист",
            "Аналитик",
            "Специалист",
            "Директор"
        };

        // Отделы
        public static string[] Departments => new[]
        {
            "Продажи",
            "Маркетинг",
            "Финансы",
            "Склад",
            "Аналитика",
            "IT"
        };

        // Инициализация данных
        public static void Initialize()
        {
            CreateDefaultFilesIfNotExist();
            LoadAllData();
        }

        // Создание файлов по умолчанию
        private static void CreateDefaultFilesIfNotExist()
        {
            Directory.CreateDirectory(BasePath);

            // products.txt
            if (!File.Exists(GetFilePath("products.txt")))
            {
                string[] defaultProducts = {
                    "1;Электроника;Смартфон Samsung A54;29999;22000;50;1",
                    "2;Электроника;Ноутбук ASUS VivoBook;59999;45000;25;1",
                    "3;Одежда;Футболка мужская;1999;1200;100;2",
                    "4;Одежда;Джинсы женские;3999;2500;75;2",
                    "5;Продукты питания;Шоколад Alpen Gold;129;80;200;3",
                    "6;Продукты питания;Кофе Jacobs;899;600;150;3"
                };
                File.WriteAllLines(GetFilePath("products.txt"), defaultProducts);
            }

            // warehouses.txt
            if (!File.Exists(GetFilePath("warehouses.txt")))
            {
                string[] defaultWarehouses = {
                    "1;ул. Ленина, 123, Москва;1000;545",
                    "2;пр. Мира, 45, Санкт-Петербург;800;175",
                    "3;ул. Садовая, 67, Казань;600;350",
                    "4;ул. Центральная, 89, Новосибирск;700;420"
                };
                File.WriteAllLines(GetFilePath("warehouses.txt"), defaultWarehouses);
            }

            // suppliers.txt
            if (!File.Exists(GetFilePath("suppliers.txt")))
            {
                string[] defaultSuppliers = {
                    "1;ООО \"Электроникс\";+7 (495) 123-45-67;4.8",
                    "2;ИП Петров;+7 (812) 987-65-43;4.2",
                    "3;АО \"Продуктовый мир\";+7 (843) 555-44-33;4.5",
                    "4;ООО \"Хозтовары\";+7 (383) 777-88-99;4.0"
                };
                File.WriteAllLines(GetFilePath("suppliers.txt"), defaultSuppliers);
            }

            // customers.txt
            if (!File.Exists(GetFilePath("customers.txt")))
            {
                string[] defaultCustomers = {
                    "1;Иванов Иван Иванович;ivanov@mail.ru;+7 (911) 111-11-11",
                    "2;Петрова Анна Сергеевна;petrova@gmail.com;+7 (922) 222-22-22",
                    "3;Сидоров Алексей;alex@yandex.ru;+7 (933) 333-33-33",
                    "4;Козлова Мария;maria@mail.ru;+7 (944) 444-44-44"
                };
                File.WriteAllLines(GetFilePath("customers.txt"), defaultCustomers);
            }

            // employees.txt
            if (!File.Exists(GetFilePath("employees.txt")))
            {
                string[] defaultEmployees = {
                    "1;Смирнов Александр Петрович;Менеджер по продажам;Продажи;50000;160",
                    "2;Орлова Екатерина Владимировна;Маркетолог;Маркетинг;45000;160",
                    "3;Кузнецов Дмитрий;Бухгалтер;Финансы;40000;160",
                    "4;Николаева Ольга;Логист;Склад;35000;160",
                    "5;Васнецов Игорь;Аналитик;Аналитика;55000;160"
                };
                File.WriteAllLines(GetFilePath("employees.txt"), defaultEmployees);
            }

            // sales.txt
            if (!File.Exists(GetFilePath("sales.txt")))
            {
                // Создаем пустой файл для продаж
                File.WriteAllText(GetFilePath("sales.txt"), "");
            }

            // purchases.txt
            if (!File.Exists(GetFilePath("purchases.txt")))
            {
                // Создаем пустой файл для закупок
                File.WriteAllText(GetFilePath("purchases.txt"), "");
            }
        }

        private static string GetFilePath(string fileName)
        {
            return Path.Combine(BasePath, fileName);
        }

        // Загрузка всех данных
        public static void LoadAllData()
        {

            LoadProducts();
            LoadWarehouses();
            LoadSuppliers();
            LoadCustomers();
            LoadEmployees();
            LoadSales(); // Добавьте эту строку
            LoadPurchases(); // Если есть закупки, тоже добавьте
        }

        // Сохранение всех данных
        public static void SaveAllData()
        {
            SaveProducts();
            SaveWarehouses();
            SaveSuppliers();
            SaveCustomers();
            SaveEmployees();
            SaveSales(); // Добавьте эту строку
            SavePurchases(); // Если есть закупки, тоже добавьте
        }

        #region Загрузка и сохранение данных
        public static void LoadProducts()
        {
            string filePath = GetFilePath("products.txt");
            if (File.Exists(filePath))
            {
                Products.Clear();
                foreach (var line in File.ReadAllLines(filePath))
                {
                    var parts = line.Split(';');
                    if (parts.Length >= 7)
                    {
                        Products.Add(new Product
                        {
                            Id = int.Parse(parts[0], CultureInfo.InvariantCulture),
                            Category = parts[1],
                            Name = parts[2],
                            Price = decimal.Parse(parts[3], CultureInfo.InvariantCulture),
                            CostPrice = decimal.Parse(parts[4], CultureInfo.InvariantCulture),
                            Quantity = int.Parse(parts[5], CultureInfo.InvariantCulture),
                            WarehouseId = int.Parse(parts[6], CultureInfo.InvariantCulture)
                        });
                    }
                }
            }
        }

        public static void SaveProducts()
        {
            string filePath = GetFilePath("products.txt");
            var lines = Products.Select(p =>
                $"{p.Id};{p.Category};{p.Name};{p.Price};{p.CostPrice};{p.Quantity};{p.WarehouseId}");
            File.WriteAllLines(filePath, lines);
        }

        public static void LoadWarehouses()
        {
            string filePath = GetFilePath("warehouses.txt");
            if (File.Exists(filePath))
            {
                Warehouses.Clear();
                foreach (var line in File.ReadAllLines(filePath))
                {
                    var parts = line.Split(';');
                    if (parts.Length >= 4)
                    {
                        Warehouses.Add(new Warehouse
                        {
                            Id = int.Parse(parts[0], CultureInfo.InvariantCulture),
                            Address = parts[1],
                            MaxCapacity = int.Parse(parts[2], CultureInfo.InvariantCulture),
                            CurrentQuantity = int.Parse(parts[3], CultureInfo.InvariantCulture)
                        });
                    }
                }
            }
        }

        public static void SaveWarehouses()
        {
            string filePath = GetFilePath("warehouses.txt");
            var lines = Warehouses.Select(w =>
                $"{w.Id};{w.Address};{w.MaxCapacity};{w.CurrentQuantity}");
            File.WriteAllLines(filePath, lines);
        }

        public static void LoadSuppliers()
        {
            string filePath = GetFilePath("suppliers.txt");
            if (File.Exists(filePath))
            {
                Suppliers.Clear();
                foreach (var line in File.ReadAllLines(filePath))
                {
                    var parts = line.Split(';');
                    if (parts.Length >= 4)
                    {
                        Suppliers.Add(new Supplier
                        {
                            Id = int.Parse(parts[0], CultureInfo.InvariantCulture),
                            Name = parts[1],
                            Contact = parts[2],
                            Rating = double.Parse(parts[3], CultureInfo.InvariantCulture)
                        });
                    }
                }
            }
        }

        public static void SaveSuppliers()
        {
            string filePath = GetFilePath("suppliers.txt");
            var lines = Suppliers.Select(s =>
                $"{s.Id};{s.Name};{s.Contact};{s.Rating}");
            File.WriteAllLines(filePath, lines);
        }

        public static void LoadCustomers()
        {
            string filePath = GetFilePath("customers.txt");
            if (File.Exists(filePath))
            {
                Customers.Clear();
                foreach (var line in File.ReadAllLines(filePath))
                {
                    var parts = line.Split(';');
                    if (parts.Length >= 4)
                    {
                        Customers.Add(new Customer
                        {
                            Id = int.Parse(parts[0], CultureInfo.InvariantCulture),
                            Name = parts[1],
                            Email = parts[2],
                            Phone = parts[3]
                        });
                    }
                }
            }
        }

        public static void SaveCustomers()
        {
            string filePath = GetFilePath("customers.txt");
            var lines = Customers.Select(c =>
                $"{c.Id};{c.Name};{c.Email};{c.Phone}");
            File.WriteAllLines(filePath, lines);
        }

        public static void LoadEmployees()
        {
            string filePath = GetFilePath("employees.txt");
            if (File.Exists(filePath))
            {
                Employees.Clear();
                foreach (var line in File.ReadAllLines(filePath))
                {
                    var parts = line.Split(';');
                    if (parts.Length >= 6)
                    {
                        Employees.Add(new Employee
                        {
                            Id = int.Parse(parts[0], CultureInfo.InvariantCulture),
                            Name = parts[1],
                            Position = parts[2],
                            Department = parts[3],
                            Salary = decimal.Parse(parts[4], CultureInfo.InvariantCulture),
                            WorkHours = int.Parse(parts[5], CultureInfo.InvariantCulture)
                        });
                    }
                }
            }
        }

        public static void SaveEmployees()
        {
            string filePath = GetFilePath("employees.txt");
            var lines = Employees.Select(e =>
                $"{e.Id};{e.Name};{e.Position};{e.Department};{e.Salary};{e.WorkHours}");
            File.WriteAllLines(filePath, lines);
        }
        #endregion

        // Вспомогательные методы
        public static Product GetProduct(int id) => Products.FirstOrDefault(p => p.Id == id);
        public static Warehouse GetWarehouse(int id) => Warehouses.FirstOrDefault(w => w.Id == id);
        public static Supplier GetSupplier(int id) => Suppliers.FirstOrDefault(s => s.Id == id);
        public static Customer GetCustomer(int id) => Customers.FirstOrDefault(c => c.Id == id);
        public static Employee GetEmployee(int id) => Employees.FirstOrDefault(e => e.Id == id);

        public static void UpdateProductQuantity(int productId, int quantityChange)
        {
            var product = GetProduct(productId);
            if (product != null)
            {
                product.Quantity += quantityChange;
                SaveProducts();
            }
        }

        // Метод для получения адреса склада по ID
        public static string GetWarehouseAddress(int warehouseId)
        {
            try
            {
                var warehouse = Warehouses.FirstOrDefault(w => w.Id == warehouseId);
                return warehouse?.Address ?? $"Склад ID: {warehouseId}";
            }
            catch
            {
                return $"Склад ID: {warehouseId}";
            }
        }

        // Бизнес-методы
        public static void AddProduct(Product product)
        {
            product.Id = Products.Any() ? Products.Max(p => p.Id) + 1 : 1;
            Products.Add(product);

            // Обновляем склад
            var warehouse = GetWarehouse(product.WarehouseId);
            if (warehouse != null)
            {
                warehouse.CurrentQuantity += product.Quantity;
                SaveWarehouses();
            }

            SaveProducts();
        }

        public static void UpdateProductPrice(int productId, decimal newPrice)
        {
            var product = GetProduct(productId);
            if (product != null)
            {
                product.Price = newPrice;
                SaveProducts();
            }
        }

        public static void AddSupplier(Supplier supplier)
        {
            supplier.Id = Suppliers.Any() ? Suppliers.Max(s => s.Id) + 1 : 1;
            Suppliers.Add(supplier);
            SaveSuppliers();
        }

        public static void AddEmployee(Employee employee)
        {
            employee.Id = Employees.Any() ? Employees.Max(e => e.Id) + 1 : 1;
            Employees.Add(employee);
            SaveEmployees();
        }

        public static void AddSale(Sale sale)
        {
            // Обновляем количество товара
            UpdateProductQuantity(sale.ProductId, -sale.Quantity);

            // Обновляем склад
            var product = GetProduct(sale.ProductId);
            if (product != null)
            {
                var warehouse = GetWarehouse(product.WarehouseId);
                if (warehouse != null)
                {
                    warehouse.CurrentQuantity -= sale.Quantity;
                    SaveWarehouses();
                }
            }

            // Добавляем продажу
            sale.Id = Sales.Any() ? Sales.Max(s => s.Id) + 1 : 1;
            Sales.Add(sale);

            // Сохраняем продажи в файл
            SaveSales(); // Добавьте эту строку
            SaveProducts(); // Сохраняем обновленные количества товаров
        }

        public static void AddPurchase(Purchase purchase)
        {
            // Обновляем количество товара
            UpdateProductQuantity(purchase.ProductId, purchase.Quantity);

            // Обновляем склад
            var product = GetProduct(purchase.ProductId);
            if (product != null)
            {
                var warehouse = GetWarehouse(product.WarehouseId);
                if (warehouse != null)
                {
                    warehouse.CurrentQuantity += purchase.Quantity;
                    SaveWarehouses();
                }
            }
        }

        public static void AddTransfer(TransferRecord transfer)
        {
            var product = GetProduct(transfer.ProductId);
            if (product != null)
            {
                // Проверяем, что товар находится на складе-отправителе
                if (product.WarehouseId != transfer.FromWarehouseId)
                {
                    throw new InvalidOperationException("Товар не находится на указанном складе-отправителе");
                }

                // Проверяем достаточность количества
                if (product.Quantity < transfer.QuantityMoved)
                {
                    throw new InvalidOperationException($"Недостаточно товара. Доступно: {product.Quantity}, запрошено: {transfer.QuantityMoved}");
                }

                var toWarehouse = GetWarehouse(transfer.ToWarehouseId);
                if (toWarehouse != null && toWarehouse.FreeSpace < transfer.QuantityMoved)
                {
                    throw new InvalidOperationException($"Недостаточно места на складе-получателе. Свободно: {toWarehouse.FreeSpace}");
                }

                // Уменьшаем количество на складе-отправителе
                product.Quantity -= transfer.QuantityMoved;

                // Обновляем склад-отправитель
                var fromWarehouse = GetWarehouse(transfer.FromWarehouseId);
                if (fromWarehouse != null)
                {
                    fromWarehouse.CurrentQuantity -= transfer.QuantityMoved;
                }

                // Ищем такой же товар на складе-получателе
                var existingProductOnToWarehouse = Products.FirstOrDefault(p =>
                    p.Name == product.Name &&
                    p.Category == product.Category &&
                    p.WarehouseId == transfer.ToWarehouseId);

                if (existingProductOnToWarehouse != null)
                {
                    // Если товар уже есть на складе-получателе - увеличиваем его количество
                    existingProductOnToWarehouse.Quantity += transfer.QuantityMoved;
                }
                else
                {
                    // Если товара нет - создаем новую запись
                    var newProduct = new Product
                    {
                        Id = Products.Any() ? Products.Max(p => p.Id) + 1 : 1,
                        Category = product.Category,
                        Name = product.Name,
                        Price = product.Price,
                        CostPrice = product.CostPrice,
                        Quantity = transfer.QuantityMoved,
                        WarehouseId = transfer.ToWarehouseId
                    };
                    Products.Add(newProduct);
                }

                // Обновляем склад-получатель
                if (toWarehouse != null)
                {
                    toWarehouse.CurrentQuantity += transfer.QuantityMoved;
                }

                // Добавляем запись о перемещении
                TransferRecords.Add(transfer);

                SaveProducts();
                SaveWarehouses();
            }
        }

        // Аналитические методы
        public static decimal GetTotalRevenue(DateTime startDate, DateTime endDate)
        {
            return Sales
                .Where(s => s.SaleDate >= startDate && s.SaleDate <= endDate)
                .Sum(s => s.TotalAmount);
        }

        public static decimal GetTotalExpenses(DateTime startDate, DateTime endDate)
        {
            // Расходы = закупки + зарплаты
            decimal purchaseCosts = Purchases
                .Where(p => p.PurchaseDate >= startDate && p.PurchaseDate <= endDate)
                .Sum(p => p.TotalAmount);

            decimal salaryCosts = Employees.Sum(e => e.Salary);

            return purchaseCosts + salaryCosts;
        }

        public static decimal GetTotalPurchaseCost(DateTime startDate, DateTime endDate)
        {
            return Purchases
                .Where(p => p.PurchaseDate >= startDate && p.PurchaseDate <= endDate)
                .Sum(p => p.TotalAmount);
        }

        public static decimal GetTotalSalaryCost()
        {
            return Employees.Sum(e => e.Salary);
        }

        public static int GetTotalProductsSold(DateTime startDate, DateTime endDate)
        {
            return Sales
                .Where(s => s.SaleDate >= startDate && s.SaleDate <= endDate)
                .Sum(s => s.Quantity);
        }

        public static int GetTotalProductsPurchased(DateTime startDate, DateTime endDate)
        {
            return Purchases
                .Where(p => p.PurchaseDate >= startDate && p.PurchaseDate <= endDate)
                .Sum(p => p.Quantity);
        }

        public static List<Product> GetTopSellingProducts(DateTime startDate, DateTime endDate, int topCount = 5)
        {
            var productSales = Sales
                .Where(s => s.SaleDate >= startDate && s.SaleDate <= endDate)
                .GroupBy(s => s.ProductId)
                .Select(g => new
                {
                    ProductId = g.Key,
                    TotalQuantity = g.Sum(s => s.Quantity),
                    TotalAmount = g.Sum(s => s.TotalAmount)
                })
                .OrderByDescending(x => x.TotalQuantity)
                .Take(topCount)
                .ToList();

            var result = new List<Product>();
            foreach (var ps in productSales)
            {
                var product = GetProduct(ps.ProductId);
                if (product != null)
                {
                    result.Add(product);
                }
            }
            return result;
        }

        public static decimal GetAverageSaleAmount(DateTime startDate, DateTime endDate)
        {
            var salesInPeriod = Sales
                .Where(s => s.SaleDate >= startDate && s.SaleDate <= endDate)
                .ToList();

            return salesInPeriod.Any() ? salesInPeriod.Average(s => s.TotalAmount) : 0;
        }

        public static int GetUniqueCustomersCount(DateTime startDate, DateTime endDate)
        {
            return Sales
                .Where(s => s.SaleDate >= startDate && s.SaleDate <= endDate)
                .Select(s => s.CustomerId)
                .Distinct()
                .Count();
        }

        // Добавьте эти методы для устранения ошибок
        public static decimal CalculateSalary(int employeeId, int workedDays)
        {
            var employee = GetEmployee(employeeId);
            if (employee != null)
            {
                decimal dailyRate = employee.Salary / 20; // 20 рабочих дней в месяце
                return dailyRate * workedDays;
            }
            return 0;
        }

        public static List<Product> GetLowStockProducts(int threshold = 10)
        {
            return Products.Where(p => p.Quantity <= threshold).ToList();
        }

        public static List<Product> GetPopularProducts(DateTime startDate, DateTime endDate)
        {
            // Временная реализация - возвращаем товары с наибольшим количеством
            return Products.OrderByDescending(p => p.Quantity).Take(5).ToList();
        }

        public static void LoadSales()
        {
            string filePath = GetFilePath("sales.txt");
            if (File.Exists(filePath))
            {
                Sales.Clear();
                foreach (var line in File.ReadAllLines(filePath))
                {
                    var parts = line.Split(';');
                    if (parts.Length >= 6)
                    {
                        Sales.Add(new Sale
                        {
                            Id = int.Parse(parts[0], CultureInfo.InvariantCulture),
                            ProductId = int.Parse(parts[1], CultureInfo.InvariantCulture),
                            Quantity = int.Parse(parts[2], CultureInfo.InvariantCulture),
                            TotalAmount = decimal.Parse(parts[3], CultureInfo.InvariantCulture),
                            SaleDate = DateTime.Parse(parts[4], CultureInfo.InvariantCulture),
                            CustomerId = int.Parse(parts[5], CultureInfo.InvariantCulture)
                        });
                    }
                }
            }
        }

        public static void SaveSales()
        {
            string filePath = GetFilePath("sales.txt");
            var lines = Sales.Select(s =>
                $"{s.Id};{s.ProductId};{s.Quantity};{s.TotalAmount};{s.SaleDate:yyyy-MM-dd HH:mm:ss};{s.CustomerId}");
            File.WriteAllLines(filePath, lines);
        }

        public static void LoadPurchases()
        {
            string filePath = GetFilePath("purchases.txt");
            if (File.Exists(filePath))
            {
                Purchases.Clear();
                foreach (var line in File.ReadAllLines(filePath))
                {
                    var parts = line.Split(';');
                    if (parts.Length >= 7)
                    {
                        Purchases.Add(new Purchase
                        {
                            Id = int.Parse(parts[0], CultureInfo.InvariantCulture),
                            ProductId = int.Parse(parts[1], CultureInfo.InvariantCulture),
                            Quantity = int.Parse(parts[2], CultureInfo.InvariantCulture),
                            TotalAmount = decimal.Parse(parts[3], CultureInfo.InvariantCulture),
                            PurchaseDate = DateTime.Parse(parts[4], CultureInfo.InvariantCulture),
                            SupplierId = int.Parse(parts[5], CultureInfo.InvariantCulture),
                            WarehouseId = int.Parse(parts[6], CultureInfo.InvariantCulture)
                        });
                    }
                }
            }
        }

        public static void SavePurchases()
        {
            string filePath = GetFilePath("purchases.txt");
            var lines = Purchases.Select(p =>
                $"{p.Id};{p.ProductId};{p.Quantity};{p.TotalAmount};{p.PurchaseDate:yyyy-MM-dd HH:mm:ss};{p.SupplierId};{p.WarehouseId}");
            File.WriteAllLines(filePath, lines);
        }

        public class User
        {
            public string Username { get; set; }
            public string Password { get; set; }
            public string Role { get; set; }
            public string FullName { get; set; }
        }

        public static class UserManager
        {
            private static List<User> _users = new List<User>();
            public static User CurrentUser { get; private set; }

            public static void LoadUsers()
            {
                string filePath = GetFilePath("users.txt");
                _users.Clear();

                if (File.Exists(filePath))
                {
                    foreach (var line in File.ReadAllLines(filePath))
                    {
                        var parts = line.Split(';');
                        if (parts.Length >= 4)
                        {
                            _users.Add(new User
                            {
                                Username = parts[0],
                                Password = parts[1],
                                Role = parts[2],
                                FullName = parts[3]
                            });
                        }
                    }
                }
                else
                {
                    CreateDefaultUsers();
                }
            }

            public static void SaveUsers()
            {
                string filePath = GetFilePath("users.txt");
                var lines = _users.Select(u =>
                    $"{u.Username};{u.Password};{u.Role};{u.FullName}");
                File.WriteAllLines(filePath, lines);
            }

            private static void CreateDefaultUsers()
            {
                _users = new List<User>
        {
            new User { Username = "admin", Password = "admin", Role = "Administrator", FullName = "Администратор системы" },
            new User { Username = "manager", Password = "manager", Role = "Manager", FullName = "Менеджер склада" },
            new User { Username = "user", Password = "user", Role = "User", FullName = "Пользователь" }
        };
                SaveUsers();
            }

            public static bool Authenticate(string username, string password)
            {
                var user = _users.FirstOrDefault(u => u.Username == username && u.Password == password);
                if (user != null)
                {
                    CurrentUser = user;
                    return true;
                }
                return false;
            }

            public static bool HasAccess(string requiredRole)
            {
                if (CurrentUser == null) return false;

                // Администратор имеет доступ ко всему
                if (CurrentUser.Role == "Administrator") return true;

                return CurrentUser.Role == requiredRole;
            }

            public static bool AddUser(string username, string password, string role, string fullName)
            {
                if (_users.Any(u => u.Username == username))
                    return false;

                _users.Add(new User
                {
                    Username = username,
                    Password = password,
                    Role = role,
                    FullName = fullName
                });
                SaveUsers();
                return true;
            }

            public static bool ChangePassword(string username, string newPassword)
            {
                var user = _users.FirstOrDefault(u => u.Username == username);
                if (user != null)
                {
                    user.Password = newPassword;
                    SaveUsers();
                    return true;
                }
                return false;
            }

            public static List<User> GetAllUsers()
            {
                return new List<User>(_users);
            }


        }
    }
}