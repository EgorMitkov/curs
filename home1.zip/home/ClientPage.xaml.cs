﻿using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;

namespace home
{
    public partial class ClientPage : Page, INotifyPropertyChanged
    {
        private System.Collections.ObjectModel.ObservableCollection<CustomerProfile> _customerProfiles = new System.Collections.ObjectModel.ObservableCollection<CustomerProfile>();
        private bool _addCustomerDialogIsVisible;

        public ClientPage()
        {
            InitializeComponent();
            LoadCustomerProfiles();
            DataContext = this;
        }

        public System.Collections.ObjectModel.ObservableCollection<CustomerProfile> CustomerProfiles => _customerProfiles;

        public bool AddCustomerDialogIsVisible
        {
            get => _addCustomerDialogIsVisible;
            set
            {
                _addCustomerDialogIsVisible = value;
                OnPropertyChanged();
            }
        }

        public string LoyaltyPointsAccumulated => "1,250 баллов";
        public string LoyaltyProgramConditions => "1 балл за каждые 10 рублей покупки";
        public string DemandAnalysis => "Высокий спрос на электронику";
        public string SalesForecast => "Рост на 15% в следующем квартале";

        private void LoadCustomerProfiles()
        {
            _customerProfiles.Clear();
            foreach (var customer in DataManager.Customers)
            {
                _customerProfiles.Add(new CustomerProfile
                {
                    FullName = customer.Name,
                    EmailAddress = customer.Email,
                    PhoneNumber = customer.Phone,
                    Region = "Москва"
                });
            }
        }

        // Обработчики для кнопок действий
        private void AddCustomer_Click(object sender, RoutedEventArgs e)
        {
            AddCustomerDialogIsVisible = true;
        }

        private void LoyaltyProgramDetails_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show($"Программа лояльности:\n\n{LoyaltyProgramConditions}\n\nНачислено баллов: {LoyaltyPointsAccumulated}",
                "Программа лояльности", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void GetPromoCode_Click(object sender, RoutedEventArgs e)
        {
            string promoCode = $"PROMO{System.DateTime.Now:yyyyMMddHHmmss}";
            MessageBox.Show($"Ваш промокод: {promoCode}\nСкидка 10% на следующую покупку!",
                "Промокод получен", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void DemandResearch_Click(object sender, RoutedEventArgs e)
        {
            var popularProducts = DataManager.GetPopularProducts(System.DateTime.Now.AddMonths(-1), System.DateTime.Now);
            string popularList = string.Join("\n", popularProducts.Take(3).Select(p => $"- {p.Name}"));

            MessageBox.Show($"Анализ спроса: {DemandAnalysis}\n\nПрогноз продаж: {SalesForecast}\n\nПопулярные товары:\n{popularList}",
                "Исследование спроса", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void SendPromotion_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Акционные предложения отправлены всем клиентам!",
                "Рассылка", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void ConfirmAddCustomer_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(NewCustomerNameTextBox.Text) ||
                string.IsNullOrWhiteSpace(NewCustomerEmailTextBox.Text) ||
                string.IsNullOrWhiteSpace(NewCustomerPhoneTextBox.Text))
            {
                MessageBox.Show("Заполните все поля!", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            var newCustomer = new Customer
            {
                Name = NewCustomerNameTextBox.Text,
                Email = NewCustomerEmailTextBox.Text,
                Phone = NewCustomerPhoneTextBox.Text
            };

            DataManager.Customers.Add(newCustomer);
            DataManager.SaveCustomers();

            // Очистка полей
            NewCustomerNameTextBox.Text = "";
            NewCustomerEmailTextBox.Text = "";
            NewCustomerPhoneTextBox.Text = "";

            LoadCustomerProfiles();
            AddCustomerDialogIsVisible = false;
            MessageBox.Show("Клиент добавлен!", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void CancelAddCustomer_Click(object sender, RoutedEventArgs e)
        {
            AddCustomerDialogIsVisible = false;
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}